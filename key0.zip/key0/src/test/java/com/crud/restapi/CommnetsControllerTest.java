package com.crud.restapi;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.crud.restapi.controller.CommentsController;
import com.crud.restapi.model.Comments;
import com.crud.restapi.service.CommentsService;

@ExtendWith(SpringExtension.class)
@WebMvcTest(value = CommentsController.class)
@WithMockUser
public class CommnetsControllerTest {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private CommentsService commentsService;

	Comments mockComments = new Comments(101, "bheem", "bheem@gmail.com", "702657618", "*****");

	// JSON request data to testing
	String exampleCourseJson = "{\n" + "  \"createdAt\": \"string\",\n" + "  \"createdBy\": \"string\",\n"
			+ "  \"lastModifiedAt\": \"string\",\n" + "  \"lastModifiedBy\": \"string\",\n"
			+ "  \"name\": \"string\",\n" + "  \"email\": \"string\",\n" + "  \"mobNo\": \"string\",\n"
			+ "  \"password\": \"string\"\n" + "}";

	@Test
	public void retrieveDetailsForCourse() throws Exception {

		Mockito.when(commentsService.getCommentsById(Mockito.anyLong())).thenReturn(mockComments);

		// map the API end points and content type
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/api/v1/getCommentsById/101")
				.accept(MediaType.APPLICATION_JSON);

		// perform the get test case using get comments API
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();

		System.out.println(result.getResponse());
		// JSON response data to testing
		String expected = "{\n" + "  \"data\": {\n" + "    \"createdAt\": \"string\",\n"
				+ "    \"createdBy\": \"string\",\n" + "    \"lastModifiedAt\": \"string\",\n"
				+ "    \"lastModifiedBy\": \"string\",\n" + "    \"id\": 1,\n" + "    \"name\": \"string\",\n"
				+ "    \"email\": \"string\",\n" + "    \"mobNo\": \"string\",\n" + "    \"password\": \"string\"\n"
				+ "  },\n" + "  \"message\": \"Comments fetched successfully !!\",\n" + "  \"success\": true\n" + "}";

		JSONAssert.assertEquals(expected, result.getResponse().getContentAsString(), false);
	}

}
