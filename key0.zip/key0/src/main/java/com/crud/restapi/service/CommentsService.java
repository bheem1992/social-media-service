package com.crud.restapi.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.crud.restapi.model.Comments;
import com.crud.restapi.repository.CommentsRepository;

@Service
public class CommentsService {

	@Autowired
	private CommentsRepository commentsRepository;

	// insert the comments object in table using @Async method call
	@Async
	public CompletableFuture<List<Comments>> insertComments(Comments reqData) {
		List<Comments> list = new ArrayList<>();
		list.add(reqData);
		list = commentsRepository.saveAll(list);
		return CompletableFuture.completedFuture(list);
	}

	// fetch the all comments list
	public List<Comments> getAllComments() {
		List<Comments> users = commentsRepository.findAll();
		return users;
	}

	public Comments isDataExist(Comments reqData) {
		return commentsRepository.findByEmailAndMobNo(reqData.getEmail(), reqData.getMobNo());
	}

	public Optional<Comments> getComments(Comments reqData) {
		return commentsRepository.findById(reqData.getId());
	}

	public Object getCommentsById(Long id) {
		return commentsRepository.findById(id);
	}

	public Object updateComments(Comments reqData, Comments isData) {
		isData.setName(reqData.getName());
		isData.setEmail(reqData.getEmail());
		isData.setMobNo(reqData.getMobNo());
		isData.setPassword(reqData.getPassword());
		return commentsRepository.save(isData);
	}

	public Object deleteCommentsById(Long id) {
		commentsRepository.deleteById(id);
		return null;
	}

}