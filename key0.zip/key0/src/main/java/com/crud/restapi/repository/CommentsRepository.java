package com.crud.restapi.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.crud.restapi.model.Comments;

public interface CommentsRepository extends JpaRepository<Comments, Long> {

	Comments findByEmailAndMobNo(String email, String mobNo);

}
