package com.crud.restapi.controller;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.crud.restapi.bean.ResultDTO;
import com.crud.restapi.model.Comments;
import com.crud.restapi.service.CommentsService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/v1")
@Tag(name = "Social media comments controller", description = "CRUD api for comments")
@CrossOrigin
public class CommentsController {

	Logger logger = LoggerFactory.getLogger(CommentsController.class);

	@Autowired
	private CommentsService commentsService;

	// method for insert comments
	@Operation(summary = "Create comments", description = "Createt the comments using mention parameters.")
	@ApiResponses({
			@ApiResponse(responseCode = "200", content = {
					@Content(schema = @Schema(implementation = Comments.class), mediaType = "application/json") }),
			@ApiResponse(responseCode = "404", content = { @Content(schema = @Schema()) }),
			@ApiResponse(responseCode = "500", content = { @Content(schema = @Schema()) }) })
	@PostMapping("/addComments")
	public ResponseEntity<?> addComments(@RequestBody Comments reqData) {
		logger.info(":::  CommentsController.addComments :::");
		ResultDTO<?> responsePacket = null;
		try {

			// duplicate data checking
			Comments isData = commentsService.isDataExist(reqData);
			if (isData == null) {
				responsePacket = new ResultDTO<>(commentsService.insertComments(reqData),
						"Comments inserted Successfully", true);
				return new ResponseEntity<>(responsePacket, HttpStatus.OK);
			} else {
				responsePacket = new ResultDTO<>("Record already exist", false);
				return new ResponseEntity<>(responsePacket, HttpStatus.BAD_REQUEST);
			}
		} catch (Exception e) {
			responsePacket = new ResultDTO<>(e.getMessage(), false);
			logger.info("ERROR  CommentsController.addComments :::" + e.getMessage());
			return new ResponseEntity<>(responsePacket, HttpStatus.BAD_REQUEST);
		}
	}

	// method for fetch all comments
	@Operation(summary = "Fetch all comments", description = "Fetch the all comments using mention parameters.")
	@GetMapping("/allComments")
	public ResponseEntity<?> allComments() {
		logger.info(":::  CommentsController.allComments :::");
		ResultDTO<?> responsePacket = null;
		try {

			responsePacket = new ResultDTO<>(commentsService.getAllComments(), "Comments fetched successfully !!",
					true);

			return new ResponseEntity<>(responsePacket, HttpStatus.OK);

		} catch (Exception e) {
			responsePacket = new ResultDTO<>(e.getMessage(), false);
			logger.info("ERROR  CommentsController.allComments :::" + e.getMessage());
			return new ResponseEntity<>(responsePacket, HttpStatus.BAD_REQUEST);
		}
	}

	
	// method for fetch comments by commentID 
	@ApiResponses({ @ApiResponse(responseCode = "200", content = {
			@Content(schema = @Schema(implementation = Comments.class), mediaType = "application/json") }), })
	@GetMapping("/getCommentsById/{id}")
	public ResponseEntity<?> getCommentsById(@PathVariable("id") Long id) {
		logger.info(":::  CommentsController.getCommentsById :::");
		ResultDTO<?> responsePacket = null;
		try {
			responsePacket = new ResultDTO<>(commentsService.getCommentsById(id), "Comments fetched successfully !!",
					true);
			return new ResponseEntity<>(responsePacket, HttpStatus.OK);
		} catch (Exception e) {
			responsePacket = new ResultDTO<>(e.getMessage(), false);
			logger.info("ERROR  CommentsController.getCommentsById :::" + e.getMessage());
			return new ResponseEntity<>(responsePacket, HttpStatus.BAD_REQUEST);
		}
	}

	// method for update comments by commentID 
	@PutMapping("/updateComments")
	public ResponseEntity<?> updateComments(@RequestBody Comments reqData) {
		logger.info(":::  CommentsController.updateComments :::");
		ResultDTO<?> responsePacket = null;
		try {
			Optional<Comments> isData = commentsService.getComments(reqData);
			if (isData.isPresent()) {
				responsePacket = new ResultDTO<>(commentsService.updateComments(reqData, isData.get()),
						"Comments Updated Successfully", true);
				return new ResponseEntity<>(responsePacket, HttpStatus.OK);
			} else {
				responsePacket = new ResultDTO<>("Record not exist", false);
				return new ResponseEntity<>(responsePacket, HttpStatus.BAD_REQUEST);
			}
		} catch (Exception e) {
			responsePacket = new ResultDTO<>(e.getMessage(), false);
			logger.info("ERROR  CommentsController.updateComments :::" + e.getMessage());
			return new ResponseEntity<>(responsePacket, HttpStatus.BAD_REQUEST);
		}
	}

	// method for delete comments by commentID 
	@DeleteMapping("/deleteCommentsById/{id}")
	public ResponseEntity<?> deleteCommentsById(@PathVariable("id") Long id) {
		logger.info(":::  CommentsController.deleteCommentsById :::");
		ResultDTO<?> responsePacket = null;
		try {
			responsePacket = new ResultDTO<>(commentsService.deleteCommentsById(id), "Comments deleted successfully !!",
					true);
			return new ResponseEntity<>(responsePacket, HttpStatus.OK);
		} catch (Exception e) {
			responsePacket = new ResultDTO<>(e.getMessage(), false);
			logger.info("ERROR  CommentsController.deleteCommentsById :::" + e.getMessage());
			return new ResponseEntity<>(responsePacket, HttpStatus.BAD_REQUEST);
		}
	}

}
